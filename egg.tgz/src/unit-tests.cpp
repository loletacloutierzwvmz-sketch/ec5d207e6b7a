// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("unit tests\n", stdout);
  return lionss_run_workload("unit-tests");
}
