// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("compile time report"); }
int main(){
  announce();
  return lionss_run_workload("compile-time-report");
}
